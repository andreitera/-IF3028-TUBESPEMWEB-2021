-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 19 Des 2020 pada 18.11
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laporpak`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_lap`
--

CREATE TABLE `data_lap` (
  `id` int(11) NOT NULL,
  `komentar` varchar(255) NOT NULL,
  `aspek` varchar(50) NOT NULL,
  `lampiran` varchar(100) NOT NULL,
  `ukuran_lamp` double NOT NULL,
  `tipe_lamp` varchar(20) NOT NULL,
  `tgl_masuk` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `data_lap`
--

INSERT INTO `data_lap` (`id`, `komentar`, `aspek`, `lampiran`, `ukuran_lamp`, `tipe_lamp`, `tgl_masuk`) VALUES
(2, 'BODO AMAT', 'Infrastruktur', '1.png', 92.2, 'image/png', '2020-12-19 17:09:46');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `data_lap`
--
ALTER TABLE `data_lap`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `data_lap`
--
ALTER TABLE `data_lap`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
