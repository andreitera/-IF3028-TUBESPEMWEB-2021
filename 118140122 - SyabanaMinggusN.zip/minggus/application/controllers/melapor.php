<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class melapor extends CI_Controller {

  public function __construct(){
    parent::__construct();

    $this->load->model('struktur_lap');
  }

  public function index(){
    $data['lampiran'] = $this->struktur_lap->view();
    $this->load->view('mainmenu/view', $data);
  }

  public function spesifik($carinama){
    $data['lampiran'] = $this->struktur_lap->ambil($carinama);
    $this->load->view('mainmenu/detail', $data);
  }

  public function tambah(){
    $data = array();

    if($this->input->post('submit')){ // Jika user menekan tombol Submit (Simpan) pada form
      // lakukan upload file dengan memanggil function upload yang ada di struktur_lap.php
      $upload = $this->struktur_lap->upload();

      if($upload['result'] == "success"){ // Jika proses upload sukses
         // Panggil function save yang ada di GambarModel.php untuk menyimpan data ke database
        $this->struktur_lap->save($upload);

        redirect(base_url()); // Redirect kembali ke halaman awal / halaman view data
      }else{ // Jika proses upload gagal
        $data['message'] = $upload['error']; // Ambil pesan error uploadnya untuk dikirim ke file form dan ditampilkan
      }
    }

    $this->load->view('mainmenu/form', $data);
  }

  public function edit($editnama){
    $data['lampiran'] = $this->struktur_lap->ambil($editnama);
    $this->load->view('mainmenu/editin', $data);
  }

  public function updatean($ambilnama){
    $data = array();

    if($this->input->post('submit')){ // Jika user menekan tombol Submit (Simpan) pada form
      // lakukan upload file dengan memanggil function upload yang ada di struktur_lap.php
      $upload = $this->struktur_lap->upload();

      if($upload['result'] == "success"){ // Jika proses upload sukses
         // Panggil function save yang ada di GambarModel.php untuk menyimpan data ke database
        $this->struktur_lap->edit($upload, $ambilnama);

        redirect(base_url()); // Redirect kembali ke halaman awal / halaman view data
      }else{ // Jika proses upload gagal
        $data['message'] = $upload['error']; // Ambil pesan error uploadnya untuk dikirim ke file form dan ditampilkan
      }
    }

    $this->load->view('mainmenu/form', $data);
  }

  public function hapus($nama){
    $this->struktur_lap->delete($nama);
    redirect(base_url());
  }
}
