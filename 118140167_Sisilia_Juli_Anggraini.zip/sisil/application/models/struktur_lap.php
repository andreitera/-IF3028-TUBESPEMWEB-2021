<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class struktur_lap extends CI_Model {
  // Fungsi untuk menampilkan semua data
  public function view(){
    return $this->db->get('data_lap')->result();
  }

  // Fungsi untuk menampilkan salah satu data
  public function ambil($nama){
    return $this->db->get_where('data_lap', array('lampiran' => $nama))->result();
  }

  // Fungsi untuk melakukan proses upload file
  public function upload(){
    $config['upload_path'] = './lampiran/';
    $config['allowed_types'] = 'jpg|png|jpeg|doc|docx|xls|xlsx|ppt|pptx|pdf';
    $config['remove_space'] = TRUE;

    $this->load->library('upload', $config); // Load konfigurasi uploadnya
    if($this->upload->do_upload('input_lampiran')){ // Lakukan upload dan Cek jika proses upload berhasil
      // Jika berhasil :
      $return = array('result' => 'success', 'file' => $this->upload->data(), 'error' => '');
      return $return;
    }else{
      // Jika gagal :
      $return = array('result' => 'failed', 'file' => '', 'error' => $this->upload->display_errors());
      return $return;
    }
  }

  // Fungsi untuk menyimpan data ke database
  public function save($upload){
    $data = array(
      'komentar' => $this->input->post('input_komentar'),
      'aspek' => $this->input->post('input_aspek'),
      'lampiran' => $upload['file']['file_name'],
      'ukuran_lamp' => $upload['file']['file_size'],
      'tipe_lamp' => $upload['file']['file_type']
    );

    $this->db->insert('data_lap', $data);
  }

  public function edit($upload, $ambilnama){
    $data = array(
      'komentar' => $this->input->post('input_komentar'),
      'aspek' => $this->input->post('input_aspek'),
      'lampiran' => $upload['file']['file_name'],
      'ukuran_lamp' => $upload['file']['file_size'],
      'tipe_lamp' => $upload['file']['file_type']
    );
    $this->db->where('lampiran', $ambilnama);
    $this->db->update('data_lap', $data);
    unlink('./lampiran/'.$ambilnama);
  }

  public function delete($nama){
    $this->db->where_in('lampiran', $nama);
    $this->db->delete('data_lap');
    unlink('./lampiran/'.$nama);
  }

  public function hapus($hapus)
  {
    unlink('./lampiran/'.$hapus);
  }
}
