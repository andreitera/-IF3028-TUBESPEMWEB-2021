<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>LAPOR PAK!</title>
    <link rel="stylesheet" href=<?php echo base_url('style.css'); ?>>
  </head>
  <body>
    <div class="garis_tepi">
      <h1>LAPOR PAK!</h1>
      <br>
      <div style="color: red;"><?php echo (isset($message))? $message : ""; ?></div>
		  <br>
      <div class="listing">
        <p>Buat Laporan/Komentar</p>
      </div>
    <hr>
    <?php echo form_open('melapor/tambah', array('enctype'=>'multipart/form-data')); ?>
    <table cellpadding="8" align="justify">
      <tr>
        <td><textarea name="input_komentar" placeholder="Buat Laporan/Komentar"></textarea></td>
      </tr>
      <tr>
        <td>
          <select id="input_aspek" name="input_aspek">
            <option>Pilih Aspek Pelaporan/Komentar</option>
            <option value="Infrastruktur">Infrastruktur</option>
            <option value="Uang Kuliah Tunggal">Uang Kuliah Tunggal</option>
            <option value="Kegiatan">Kegiatan</option>
          </select>
        </td>
      </tr>
      <tr>
        <td><input type="file" name="input_lampiran"></td>
      </tr>
    </table>
    <input type="submit" name="submit" value="Simpan">
    <a href="<?php echo base_url(); ?>"><input type="button" value="Batal"></a>
  <?php echo form_close(); ?>
      <br><br>
    </div>
  </body>
</html>
